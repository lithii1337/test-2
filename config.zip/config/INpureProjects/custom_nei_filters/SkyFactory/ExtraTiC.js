
NEI.hide("ExtraTiC", "moltenRedAurum");
NEI.hide("ExtraTiC", "moltenAdamantine");
NEI.hide("ExtraTiC", "moltenZinc");
//NEI.hide(<ExtraTiC:extra.bucket:10>);
//NEI.hide(<ExtraTiC:extra.bucket:12>);
//ExtraTiC:blockFunStuff:2>