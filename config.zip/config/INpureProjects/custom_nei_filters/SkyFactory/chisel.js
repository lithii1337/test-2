



NEI.hide("chisel", "aluminum_stairs.7");
NEI.hide("chisel", "aluminum_stairs.6");
NEI.hide("chisel", "aluminum_stairs.5");
NEI.hide("chisel", "aluminum_stairs.4");
NEI.hide("chisel", "aluminum_stairs.3");

NEI.hide("chisel", "amber");
