


NEI.hide("lootplusplus", "barrier");
NEI.hide("lootplusplus", "command_block_trigger");
NEI.hide("lootplusplus", "command_trigger_block");
NEI.hide("lootplusplus", "command_trigger_item");
NEI.hide("lootplusplus", "custom_spawn_egg");
NEI.hide("lootplusplus", "dummy_tab_icon_present");
NEI.hide("lootplusplus", "dummy_tab_icon_record");
NEI.hide("lootplusplus", "loot_chest");
NEI.hide("lootplusplus", "nbt_checker");
NEI.hide("lootplusplus", "single_entity_spawner");
NEI.hide("lootplusplus", "loot_item");
