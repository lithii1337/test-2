if (FML.isModLoaded("appliedenergistics2") && AE2_enabled) {
    NEI.override(AE2.getFacadeItem(), [java.random(AE2.getNumberOfTypes())]);
}


    NEI.override("appliedenergistics2:item.ItemMultiMaterial", [0, 28, 44, 25, 52, 23, 16, 27, 53, 29, 31, 26, 30, 33, 37, 35, 32, 36, 38, 1, 2, 39, 24, 17, 4, 7, 8, 9, 43, 22, 18, 6, 3, 10, 12, 11, 48, 20, 47, 45, 41, 42, 40]);

//NEI.hide(<appliedenergistics2:item.ItemMultiMaterial:13>);
//NEI.hide(<appliedenergistics2:item.ItemMultiMaterial:14>);
//NEI.hide(<appliedenergistics2:item.ItemMultiMaterial:15>);
//NEI.hide(<appliedenergistics2:item.ItemMultiMaterial:19>);
//NEI.hide(<appliedenergistics2:item.ItemMultiMaterial:21>);